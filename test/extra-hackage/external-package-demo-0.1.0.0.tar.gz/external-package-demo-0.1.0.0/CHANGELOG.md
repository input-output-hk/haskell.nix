# Revision history for external-package-demo

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
